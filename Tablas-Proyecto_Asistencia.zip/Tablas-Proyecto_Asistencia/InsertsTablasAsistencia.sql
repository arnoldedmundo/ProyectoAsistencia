------------Tabla Empleado---------------------------------------

INSERT INTO Empleado (
    IdUsuario,
    CodigoEmpleado,
    Nombre,
    ApellidoPaterno,
    ApellidoMaterno,
    Area,
    Direccion,
    Celular,
    CorreoElectronico,
    Estado,
    FechaIngreso,
    IdSupervisor
)
VALUES (
    2,                      -- IdUsuario
    'EMP002',               -- CodigoEmpleado
    'Mar�a',                -- Nombre
    'L�pez',                -- ApellidoPaterno
    'Fern�ndez',            -- ApellidoMaterno
    'Contabilidad',         -- Area
    'Calle Falsa 456',      -- Direccion
    '0987654321',           -- Celular
    'maria.lopez@email.com',-- CorreoElectronico
    1,                      -- Estado (Activo)
    GETDATE(),              -- Fecha de Ingreso (Fecha actual por defecto)
    1                       -- IdSupervisor (Empleado con IdEmpleado 1 como supervisor)
);

--select * from empleado


------------------------------Tabla Usuario--------------------------------------------------------------------

INSERT INTO Usuario (
    IdEstado,
    NombreUsuario,
    CorreoElectronico,
    Contrase�aHash,
    Rol,
    NumeroTelefono,
    Direccion,
    UsuarioCreacion,
    FechaActivacion,
    EsReferido
)
VALUES (
    1,                             -- IdEstado (Activo)
    'marysmith',                   -- NombreUsuario
    'mary.smith@email.com',        -- CorreoElectronico
    'hashedpassword456',           -- Contrase�aHash (encriptada)
    'Usuario',                     -- Rol (Usuario regular)
    '555-6789',                    -- NumeroTelefono
    '456 Another St',              -- Direccion
    1,                             -- UsuarioCreacion (creado por el usuario con ID 1)
    GETDATE(),                     -- FechaActivacion (fecha actual)
    1                              -- EsReferido (fue referido)
);


--select * from usuario

---------------------Tabla Asistencia-------------------------------------------------------------

INSERT INTO Asistencia (
    IdEmpleado,
    Fecha,
    RegistroEntrada,
    RegistroSalida,
    TipoAsistencia
)
VALUES (
    1,                             -- IdEmpleado (Empleado con ID 1)
    '2024-10-03',                  -- Fecha (Fecha del registro)
    '2024-10-03 08:00:00',         -- RegistroEntrada (Hora de entrada)
    '2024-10-03 17:00:00',         -- RegistroSalida (Hora de salida)
    'Presencial'                   -- TipoAsistencia (Presencial)
);

INSERT INTO Asistencia (
    IdEmpleado,
    Fecha,
    RegistroEntrada,
    RegistroSalida,
    TipoAsistencia
)
VALUES (
    2,                             -- IdEmpleado (Empleado con ID 2)
    '2024-10-03',                  -- Fecha (Fecha del registro)
    '2024-10-03 09:00:00',         -- RegistroEntrada (Hora de entrada)
    NULL,                          -- RegistroSalida (a�n no registrado)
    'Remoto'                       -- TipoAsistencia (Remoto)
);

--select * from Asistencia

---------------Tabla Horarios--------------------
INSERT INTO Horarios (
    IdEmpleado,
    HoraEntrada,
    HoraSalida,
    DiaSemana,
    Turno,
    Estado,
    FechaInicio,
    FechaFin,
    HorasTrabajadas,
    Comentarios,
    TipoTurno,
    Flexible,
    Duraci�n_Actividad,
    Ubicaci�n,
    UltimaModificacion,
    UsuarioModificacion
)
VALUES (
    1,                          -- IdEmpleado (Empleado con ID 1)
    '08:00',                    -- HoraEntrada (hora de entrada en formato string)
    '17:00',                    -- HoraSalida (hora de salida en formato string)
    'Lunes',                    -- DiaSemana (d�a de la semana)
    'Ma�ana',                   -- Turno (Ma�ana)
    1,                          -- Estado (Activo)
    '2024-10-01',               -- FechaInicio (Fecha de inicio del horario)
    '2024-12-31',               -- FechaFin (Fecha de fin del horario)
    8,                          -- HorasTrabajadas (N�mero de horas trabajadas)
    'Horario regular',          -- Comentarios (Comentarios adicionales)
    'Regular',                  -- TipoTurno (Tipo de turno)
    0,                          -- Flexible (No es flexible)
    540,                        -- Duraci�n_Actividad (Duraci�n del turno en minutos)
    'Oficina Central',          -- Ubicaci�n (Ubicaci�n del trabajo)
    GETDATE(),                  -- UltimaModificacion (Fecha de la �ltima modificaci�n)
    'admin'                     -- UsuarioModificacion (Usuario que hizo la modificaci�n)
);




--select * from Horarios

----------------------------Tabla Permisos -------------------------------------------
INSERT INTO Permisos (
    IdEmpleado,
    FechaPermiso,
    TipoPermiso,
    EstadoPermiso,
    Observaciones,
    Estado
)
VALUES (
    1,                           -- IdEmpleado
    '2024-10-01',                -- FechaPermiso
    'Vacaciones',                -- TipoPermiso
    'Aprobado',                  -- EstadoPermiso
    'Vacaciones de una semana',  -- Observaciones
    1                            -- Estado (Activo)
);


--select * from Permisos

--------------Tabla ReportesAsistencia--------------------------

INSERT INTO ReportesAsistencia (
    IdEmpleado,
    Mes,
    Anio,
    TotalDiasTrabajados,
    TotalHorasTrabajadas,
    TotalPermisos
)
VALUES (
    1,          -- IdEmpleado
    10,         -- Mes (Octubre)
    2024,       -- Anio
    22,         -- TotalDiasTrabajados
    176,        -- TotalHorasTrabajadas (22 d�as * 8 horas)
    2           -- TotalPermisos (d�as de permiso)
);
--select * from ReportesAsistencia

--------------------Tabla Roles------------------
INSERT INTO Roles (
    NombreRol,
    Descripcion
)
VALUES (
    'Admin',                      -- NombreRol
    'Rol con todos los permisos'  -- Descripci�n del rol
);

--select * from Roles
--------------------Tabla UsuarioRoles------------------------

INSERT INTO UsuarioRoles (
    IdUsuario,
    IdRol
)
VALUES (
    1,      -- IdUsuario (Usuario con ID 1)
    1       -- IdRol (Rol con ID 1 - Admin)
);
--select * from UsuarioRoles
---------------------Tabla Semana --------------------------------

INSERT INTO Semana (
    idEmpleado,
    Fecha,
    Estado,
    Cliente,
    AreaProyecto,
    Equipo,
    IdProbador
)
VALUES (
    1,                            -- IdEmpleado
    '2024-10-03',                 -- Fecha
    'ClientesVarios',             -- Estado
    'Cliente A',                  -- Cliente
    'Desarrollo Web',             -- AreaProyecto
    'Equipo 1',                   -- Equipo
    NULL                          -- IdProbador (valor NULL)
);
--select * from Semana

------------------Tabla SemanaActividad-------------------------------


INSERT INTO SemanaActividad (
    IdSemana,
    Cliente,
    AreaProyecto,
    Equipo,
    Dia,
    Actividad,
    Descripcion,
    Horas
)
VALUES (
    1,                            -- IdSemana
    'Cliente A',                  -- Cliente
    'Desarrollo Web',             -- AreaProyecto
    'Equipo 1',                   -- Equipo
    'Lunes',                      -- Dia
    'Desarrollo de m�dulo X',     -- Actividad
    'Implementaci�n y pruebas del m�dulo X', -- Descripci�n
    8.00                          -- Horas (8 horas)
);
--select * from SemanaActividad




----/Resumen de tablas:
--Empleado: Almacena informaci�n sobre los empleados.
--Asistencia: Registra la asistencia de los empleados (entradas y salidas).
---Horarios: Define los horarios de trabajo para cada empleado.
---Permisos: Gestiona los permisos solicitados por los empleados.
----ReportesAsistencia: Almacena reportes de asistencia por mes y a�o.
----Configuracion: Almacena configuraciones generales del sistema.
----Roles: Define los roles de usuario dentro del sistema.
---UsuarioRoles: Asocia usuarios a sus roles correspondientes.-------
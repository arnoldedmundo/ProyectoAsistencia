CREATE TABLE Empleado (
    IdEmpleado INT IDENTITY(1,1) PRIMARY KEY,
	IdUsuario  INT NOT NULL,
    CodigoEmpleado VARCHAR(10) NOT NULL UNIQUE,
    Nombre VARCHAR(50) NOT NULL,
    ApellidoPaterno VARCHAR(50) NOT NULL,
    ApellidoMaterno VARCHAR(50),
    Area VARCHAR(50),
    Direccion VARCHAR(500) NOT NULL,
    Celular VARCHAR(10) NOT NULL,
    CorreoElectronico VARCHAR(50) NOT NULL UNIQUE,
    Estado INT NOT NULL,
    FechaIngreso DATETIME NOT NULL DEFAULT GETDATE(),  -- Fecha de ingreso a la empresa
    IdSupervisor INT,  -- ID del supervisor (FK)
    CONSTRAINT FK_Empleado_Supervisor FOREIGN KEY (IdSupervisor) REFERENCES Empleado(IdEmpleado),
);


CREATE TABLE Usuario (
    IdUsuario INT IDENTITY(1,1) PRIMARY KEY,  -- Identificador �nico
    IdEstado INT NOT NULL,             -- Estado del usuario (activo, inactivo, etc.)
	NombreUsuario VARCHAR(50) NOT NULL, -- Nombre del usuario para autenticaci�n
	CorreoElectronico VARCHAR(100) NOT NULL UNIQUE, -- Correo electr�nico �nico
    Contrase�aHash VARCHAR(255) NOT NULL, -- Contrase�a hasheada del usuario
    Rol VARCHAR(50) NOT NULL, -- Rol del usuario (Admin, Usuario, etc.)
    UltimoAcceso DATETIME,    -- �ltima fecha de acceso del usuario
    EstadoCuenta VARCHAR(50) NOT NULL DEFAULT 'Activo', -- Estado de la cuenta (Activo, Bloqueado, etc.)
    NumeroTelefono VARCHAR(15),  -- N�mero de tel�fono del usuario
    Direccion VARCHAR(255),      -- Direcci�n f�sica del usuario
    UsuarioCreacion INT NOT NULL,      -- ID del usuario que cre� el registro
    FechaCreacion DATETIME NOT NULL DEFAULT GETDATE(),  -- Fecha de creaci�n del registro
    UsuarioModificacion INT,           -- ID del usuario que modific� el registro
    FechaModificacion DATETIME,        -- Fecha de la �ltima modificaci�n
    FechaActivacion DATETIME,          -- Fecha de activaci�n del usuario
    RutaFoto VARCHAR(255),             -- Ruta de la foto del usuario
    EsReferido BIT NOT NULL DEFAULT 0, -- Indica si el usuario fue referido (0 o 1)
 
);



CREATE TABLE Asistencia (
    IdAsistencia INT IDENTITY(1,1) PRIMARY KEY,
    IdEmpleado INT NOT NULL,  -- FK a la tabla Empleado
    Fecha DATETIME NOT NULL,
    RegistroEntrada DATETIME,  -- Hora de entrada
    RegistroSalida DATETIME,    -- Hora de salida
    TipoAsistencia VARCHAR(20), -- (Presencial, Remoto, etc.)
    CONSTRAINT FK_Asistencia_Empleado FOREIGN KEY (IdEmpleado) REFERENCES Empleado(IdEmpleado)
);



CREATE TABLE Horarios (
    IdHorario INT IDENTITY(1,1) PRIMARY KEY,
    IdEmpleado INT NOT NULL,  -- FK a la tabla Empleado
    HoraEntrada VARCHAR(20) NOT NULL,   -- Hora de entrada
    HoraSalida VARCHAR(20) NOT NULL,    -- Hora de salida
    DiaSemana VARCHAR(10) NOT NULL, -- (Lunes, Martes, etc.)
    Turno VARCHAR(20) NOT NULL,  -- (Ma�ana, Tarde, Nocturno)
    Estado INT NOT NULL DEFAULT 1,  -- (1: Activo, 0: Inactivo)
    FechaInicio DATETIME,  
    FechaFin DATETIME,     
    HorasTrabajadas INT, -- N�mero de horas que corresponde trabajar
    Comentarios VARCHAR(250), -- Comentarios adicionales
    TipoTurno VARCHAR(50), -- Regular, extraordinario, etc.
    Flexible int DEFAULT 0, -- Horario flexible o no
    Duraci�n_Actividad INT, -- Duraci�n del turno en minutos
    Ubicaci�n VARCHAR(100), -- Ubicaci�n donde debe trabajar el empleado
    UltimaModificacion DATETIME DEFAULT GETDATE(), -- Fecha de la �ltima modificaci�n
    UsuarioModificacion VARCHAR(50), -- Usuario que hizo la �ltima modificaci�n
    CONSTRAINT FK_Horarios_Empleado FOREIGN KEY (IdEmpleado) REFERENCES Empleado(IdEmpleado)
);




CREATE TABLE Permisos (
    IdPermiso INT IDENTITY(1,1) PRIMARY KEY,
    IdEmpleado INT NOT NULL,  -- FK a la tabla Empleado
    FechaPermiso DATETIME NOT NULL,  -- Fecha del permiso
    TipoPermiso VARCHAR(50) NOT NULL,  -- (Vacaciones, Enfermedad, Personal, etc.)
    EstadoPermiso VARCHAR(20) NOT NULL DEFAULT 'Pendiente',  -- (Aprobado, Pendiente, Rechazado)
    Observaciones VARCHAR(250),  -- Notas sobre el permiso
    Estado INT NOT NULL DEFAULT 1, -- (1: Activo, 0: Inactivo)
    CONSTRAINT FK_Permisos_Empleado FOREIGN KEY (IdEmpleado) REFERENCES Empleado(IdEmpleado)
);

CREATE TABLE ReportesAsistencia (
    IdReporte INT IDENTITY(1,1) PRIMARY KEY,
    IdEmpleado INT NOT NULL,  -- FK a la tabla Empleado
    Mes INT NOT NULL,           -- Mes del reporte
    Anio INT NOT NULL,         -- A�o del reporte
    TotalDiasTrabajados INT,   -- Total de d�as trabajados en el mes
    TotalHorasTrabajadas INT,   -- Total de horas trabajadas en el mes
    TotalPermisos INT,         -- Total de d�as con permisos
    CONSTRAINT FK_ReportesAsistencia_Empleado FOREIGN KEY (IdEmpleado) REFERENCES Empleado(IdEmpleado)
);



CREATE TABLE Roles (
    IdRol INT IDENTITY(1,1) PRIMARY KEY,
    NombreRol VARCHAR(50) NOT NULL UNIQUE,  -- Nombre del rol
    Descripcion VARCHAR(255)                 -- Descripci�n del rol
);


CREATE TABLE UsuarioRoles (
    IdUsuarioRol INT IDENTITY(1,1) PRIMARY KEY,
    IdUsuario INT NOT NULL,  -- FK a la tabla Usuario
    IdRol INT NOT NULL,      -- FK a la tabla Roles
    CONSTRAINT FK_UsuarioRoles_Usuario FOREIGN KEY (IdUsuario) REFERENCES Usuario(IdUsuario),
    CONSTRAINT FK_UsuarioRoles_Roles FOREIGN KEY (IdRol) REFERENCES Roles(IdRol)
);



CREATE TABLE Semana (
    IdSemana INT PRIMARY KEY IDENTITY(1,1),
    idEmpleado INT NOT NULL,  -- Relaci�n con la tabla Colaborador
    Fecha DATETIME NOT NULL,
    Estado VARCHAR(50) NOT NULL,  -- Estado de la semana (e.g. ClientesVarios)
    Cliente VARCHAR(100) NOT NULL,
    AreaProyecto VARCHAR(100) NOT NULL,
    Equipo VARCHAR(50) NOT NULL,
    IdProbador INT NULL,  -- Puede referirse a una persona que prueba el proyecto
    CONSTRAINT FK_Semana_Colaborador FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado)
);



CREATE TABLE SemanaActividad (
    IdActividad INT PRIMARY KEY IDENTITY(1,1),
    IdSemana INT NOT NULL,  -- Relaci�n con la tabla Semana
    Cliente VARCHAR(100) NOT NULL,
    AreaProyecto VARCHAR(100) NOT NULL,
    Equipo VARCHAR(50) NOT NULL,
    Dia VARCHAR(50) NOT NULL,  -- D�a de la semana
    Actividad VARCHAR(250) NOT NULL,  -- Descripci�n de la actividad
    Descripcion VARCHAR(500) NULL,  -- Detalles adicionales sobre la actividad
    Horas DECIMAL(5,2) NOT NULL,  -- Horas dedicadas
    CONSTRAINT FK_Actividad_Semana FOREIGN KEY (IdSemana) REFERENCES Semana(IdSemana)
);
